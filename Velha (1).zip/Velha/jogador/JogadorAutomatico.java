package jogador;

public class JogadorAutomatico implements Jogador
{
    private Marca     marca     = null;
    private Tabuleiro tabDoJogo = null;

    public JogadorAutomatico (Tabuleiro tab) throws Exception
    {   tabDoJogo = tab;
        // atribuir tab para tabDoJogo
        // fazer o jogador escolher sua marca
        // via sorteio de numeros aleatorio
        if ((int)(Math.random()*2) == 0)
            marca=new marca('X');
        else
            marca=new marca('O');
    }

    public JogadorAutomatico (Tabuleiro tab, Marca mrc) throws Exception
    {
        // atribuir tab para tabDoJogo
        // e mrc para marca
    }

    public Marca getMarca ()
    {
        // retorna a marca do jogador
    }

    public void facaSuaJogada ()
    {
        try
        {
            // tentando ganhar na linha 0
            if ... else if ... else if ...
            else
            // tentando ganhar na linha 1
            if ... else if ... else if ...
            else
            // tentando ganhar na linha 2
            if ... else if ... else if ...
            else
            // tentando ganhar na coluna 0
            if ... else if ... else if ...
            else
            // tentando ganhar na coluna 1
            if ... else if ... else if ...
            else
            // tentando ganhar na coluna 2
            if ... else if ... else if ...
            else
            // tentando ganhar na diagonal principal
            if ... else if ... else if ...
            else
            // tentando ganhar na diagonal secundaria
            if ... else if ... else if ...
            else
            // tentando atrapalhar vitoria na linha 0
            if ... else if ... else if ...
            else
            // tentando atrapalhar vitoria na linha 1
            if ... else if ... else if ...
            else
            // tentando atrapalhar vitoria na linha 2
            if ... else if ... else if ...
            else
            // tentando atrapalhar vitoria na coluna 0
            if ... else if ... else if ...
            else
            // tentando atrapalhar vitoria na coluna 1
            if ... else if ... else if ...
            else
            // tentando atrapalhar vitoria na coluna 2
            if ... else if ... else if ...
            else
            // tentando atrapalhar vitoria na diagonal principal
            if ... else if ... else if ...
            else
            // tentando atrapalhar vitoria na diagonal secundaria
            if ... else if ... else if ...
            else
            // tentando jogada de futuro na linha 0
            if ... else if ... else if ...
            else
            // tentando jogada de futuro na linha 1
            if ... else if ... else if ...
            else
            // tentando jogada de futuro na linha 2
            if ... else if ... else if ...
            else
            // tentando jogada de futuro na coluna 0
            if ... else if ... else if ...
            else
            // tentando jogada de futuro na coluna 1
            if ... else if ... else if ...
            else
            // tentando jogada de futuro na coluna 2
            if ... else if ... else if ...
            else
            // tentando jogada de futuro na diagonal principal
            if ... else if ... else if ...
            else
            // tentando jogada de futuro na diagonal secundaria
            if ... else if ... else if ...
            else
            // termine jogando num lugar qualquer que esteja livre
        }
        catch (Exception erro)
        {} // ignorando pois sei que n o estou usando posicao invalida nem comparando com equals um null
    }
}